package ch.schoeb.opendatatransport.model;

/**
 * Created by admin on 08.03.2015.
 */
public class Walk {
    private String duration;

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }
}
