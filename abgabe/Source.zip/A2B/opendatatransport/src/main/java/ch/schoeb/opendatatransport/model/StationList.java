package ch.schoeb.opendatatransport.model;

import java.util.List;

public class StationList{
    private List<Station> stations;


    public List<Station> getStations() {
        return stations;
    }

    public void setStations(List<Station> stations) {
        this.stations = stations;
    }
}
