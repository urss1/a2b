package hsr.rafurs.a2b;

import android.content.SharedPreferences;

import hsr.rafurs.a2b.SearchResult.SearchResultItem;

/**
 * Created by admin on 07.03.2015.
 */
public class Global {
    public static SearchResultItem searchResultItem = null;
    public static SharedPreferences sharePreference = null;
}
